#!/usr/bin/env python3
"""
Initialize database with test data
Run: python init_db.py
"""

import sqlite3
import hashlib
from datetime import datetime, timedelta
import random

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def init_test_data():
    conn = sqlite3.connect("qadam.db")
    cursor = conn.cursor()
    
    print("Clearing existing tables...")
    cursor.execute("DELETE FROM audit_log")
    cursor.execute("DELETE FROM applications")
    cursor.execute("DELETE FROM internships")
    cursor.execute("DELETE FROM users")
    
    print("Creating test users...")
    
    password_hash = hash_password("password123")
    
    users = [
        ("admin", "admin@qadam.kz", password_hash, "Admin User", "admin", None),
        ("student1", "student1@mail.kz", password_hash, "Aidos Kairbekov", "student", None),
        ("student2", "student2@mail.kz", password_hash, "Diana Sagintayeva", "student", None),
        ("student3", "student3@mail.kz", password_hash, "Ruslan Akhmetov", "student", None),
        ("techhub", "hr@techhub.kz", password_hash, "TechHub Kazakhstan", "employer", None),
        ("datasci", "hr@datascience.kz", password_hash, "DataScience KZ", "employer", None),
        ("kaspi", "hr@kaspi.kz", password_hash, "Kaspi.kz", "employer", None),
        ("aigul", "aigul@mentor.kz", password_hash, "Aigul Serikbayeva", "mentor", None),
        ("damir", "damir@mentor.kz", password_hash, "Damir Nurpeisov", "mentor", None),
    ]
    
    cursor.executemany("""
    INSERT INTO users (username, email, password_hash, full_name, role, h3_index)
    VALUES (?, ?, ?, ?, ?, ?)
    """, users)
    
    print("Creating test internships...")
    
    locations = [
        ("Almaty", 43.2220, 76.8512),
        ("Astana", 51.1694, 71.4491),
        ("Karaganda", 49.8029, 73.0874),
        ("Shymkent", 42.3149, 69.5958),
        ("Remote", 0, 0),
    ]
    
    internships = []
    for i in range(15):
        loc_name, lat, lng = random.choice(locations)
        
        import h3
        h3_index = h3.geo_to_h3(lat, lng, 8) if lat != 0 else "88283082b9fffff"
        
        internships.append((
            f"Internship {i+1}",
            random.choice(["TechHub", "DataScience KZ", "Kaspi.kz", "Halyk Bank", "Chocofamily"]),
            f"Description for internship {i+1}",
            loc_name,
            lat,
            lng,
            h3_index,
            random.randint(100000, 150000),
            random.randint(150000, 250000),
            random.randint(5, 7),
            (datetime.now() + timedelta(days=random.randint(15, 60))).strftime("%Y-%m-%d"),
            "active"
        ))
    
    cursor.executemany("""
    INSERT INTO internships 
    (title, company, description, location, location_lat, location_lng, 
     h3_index, salary_min, salary_max, employer_id, deadline, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, internships)
    
    print("Creating test applications...")
    
    applications = []
    for i in range(20):
        applications.append((
            random.randint(1, 4),
            random.randint(1, 15),
            random.choice(["pending", "reviewed", "interview", "rejected"]),
            f"Cover letter for application {i+1}"
        ))
    
    cursor.executemany("""
    INSERT INTO applications (user_id, internship_id, status, cover_letter)
    VALUES (?, ?, ?, ?)
    """, applications)
    
    print("Creating test audit logs...")
    
    audit_logs = []
    actions = ["login.success", "internship.viewed", "application.created", "profile.updated"]
    
    for i in range(30):
        audit_logs.append((
            random.randint(1, 9),
            random.choice(["student1", "techhub", "admin"]),
            random.choice(actions),
            random.choice(["user", "internship", "application"]),
            random.randint(1, 15),
            None,
            None,
            "127.0.0.1"
        ))
    
    cursor.executemany("""
    INSERT INTO audit_log (user_id, username, action, entity_type, entity_id, old_value, new_value, ip_address)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, audit_logs)
    
    conn.commit()
    conn.close()
    
    print("\nDatabase successfully initialized with test data!")
    print("\nTest users:")
    print("   - Admin: admin / password123")
    print("   - Student: student1 / password123")
    print("   - Employer: techhub / password123")
    print("   - Mentor: aigul / password123")
    print("\nStart server: uvicorn app.main:app --reload")

if __name__ == "__main__":
    import h3
    init_test_data()