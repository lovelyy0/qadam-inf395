import sqlite3
import hashlib
from datetime import datetime, timedelta
import random

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Сначала создаем таблицы
conn = sqlite3.connect("qadam.db")
cursor = conn.cursor()

# Users table
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT CHECK(role IN ('student', 'employer', 'mentor', 'admin')) NOT NULL,
    location_lat REAL,
    location_lng REAL,
    h3_index TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")

# Internships table
cursor.execute("""
CREATE TABLE IF NOT EXISTS internships (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    company TEXT NOT NULL,
    description TEXT,
    location TEXT NOT NULL,
    location_lat REAL,
    location_lng REAL,
    h3_index TEXT NOT NULL,
    salary_min INTEGER,
    salary_max INTEGER,
    employer_id INTEGER NOT NULL,
    deadline DATE,
    status TEXT DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employer_id) REFERENCES users(id)
)
""")

# Applications table
cursor.execute("""
CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    internship_id INTEGER NOT NULL,
    status TEXT CHECK(status IN ('pending', 'reviewed', 'interview', 'rejected', 'accepted')) DEFAULT 'pending',
    cover_letter TEXT,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (internship_id) REFERENCES internships(id)
)
""")

# Audit log table
cursor.execute("""
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    username TEXT,
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id INTEGER,
    old_value TEXT,
    new_value TEXT,
    ip_address TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)
""")

# Region analytics table
cursor.execute("""
CREATE TABLE IF NOT EXISTS region_analytics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    h3_index TEXT UNIQUE NOT NULL,
    total_internships INTEGER DEFAULT 0,
    avg_salary_min INTEGER,
    avg_salary_max INTEGER,
    companies_count INTEGER DEFAULT 0,
    applications_count INTEGER DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")

print("Tables created successfully!")

# Очищаем таблицы
cursor.execute("DELETE FROM audit_log")
cursor.execute("DELETE FROM applications")
cursor.execute("DELETE FROM internships")
cursor.execute("DELETE FROM users")
print("Tables cleared!")

# Создаем тестовых пользователей
password_hash = hash_password("password123")

users = [
    ("admin", "admin@qadam.kz", password_hash, "Admin User", "admin", None),
    ("student1", "student1@mail.kz", password_hash, "Aidos Kairbekov", "student", None),
    ("student2", "student2@mail.kz", password_hash, "Diana Sagintayeva", "student", None),
    ("student3", "student3@mail.kz", password_hash, "Ruslan Akhmetov", "student", None),
    ("techhub", "hr@techhub.kz", password_hash, "TechHub Kazakhstan", "employer", None),
    ("datasci", "hr@datascience.kz", password_hash, "DataScience KZ", "employer", None),
    ("kaspi", "hr@kaspi.kz", password_hash, "Kaspi.kz", "employer", None),
    ("aigul", "aigul@mentor.kz", password_hash, "Aigul Serikbayeva", "mentor", None),
    ("damir", "damir@mentor.kz", password_hash, "Damir Nurpeisov", "mentor", None),
]

cursor.executemany("""
INSERT INTO users (username, email, password_hash, full_name, role, h3_index)
VALUES (?, ?, ?, ?, ?, ?)
""", users)
print("Test users created!")

# Создаем тестовые стажировки
locations = [
    ("Almaty", 43.2220, 76.8512),
    ("Astana", 51.1694, 71.4491),
    ("Karaganda", 49.8029, 73.0874),
    ("Shymkent", 42.3149, 69.5958),
    ("Remote", 0, 0),
]

internships = []
for i in range(15):
    loc_name, lat, lng = random.choice(locations)
    
    # Простой H3 индекс для демо
    h3_index = f"h3_{i}_{lat}_{lng}"
    
    internships.append((
        f"Internship {i+1}",
        random.choice(["TechHub", "DataScience KZ", "Kaspi.kz", "Halyk Bank", "Chocofamily"]),
        f"Description for internship {i+1}",
        loc_name,
        lat,
        lng,
        h3_index,
        random.randint(100000, 150000),
        random.randint(150000, 250000),
        random.randint(5, 7),
        (datetime.now() + timedelta(days=random.randint(15, 60))).strftime("%Y-%m-%d"),
        "active"
    ))

cursor.executemany("""
INSERT INTO internships 
(title, company, description, location, location_lat, location_lng, 
 h3_index, salary_min, salary_max, employer_id, deadline, status)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
""", internships)
print("Test internships created!")

# Создаем тестовые отклики
applications = []
for i in range(20):
    applications.append((
        random.randint(1, 4),
        random.randint(1, 15),
        random.choice(["pending", "reviewed", "interview", "rejected"]),
        f"Cover letter for application {i+1}"
    ))

cursor.executemany("""
INSERT INTO applications (user_id, internship_id, status, cover_letter)
VALUES (?, ?, ?, ?)
""", applications)
print("Test applications created!")

# Создаем тестовые audit логи
audit_logs = []
actions = ["login.success", "internship.viewed", "application.created", "profile.updated"]

for i in range(30):
    audit_logs.append((
        random.randint(1, 9),
        random.choice(["student1", "techhub", "admin"]),
        random.choice(actions),
        random.choice(["user", "internship", "application"]),
        random.randint(1, 15),
        None,
        None,
        "127.0.0.1"
    ))

cursor.executemany("""
INSERT INTO audit_log (user_id, username, action, entity_type, entity_id, old_value, new_value, ip_address)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
""", audit_logs)
print("Test audit logs created!")

conn.commit()
conn.close()

print("\n✅ Database successfully initialized with test data!")
print("\nTest users:")
print("   - Admin: admin / password123")
print("   - Student: student1 / password123")
print("   - Employer: techhub / password123")
print("   - Mentor: aigul / password123")
print("\nStart server: uvicorn app.main:app --reload")