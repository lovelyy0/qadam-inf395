from fastapi import FastAPI, Depends, HTTPException, status
from typing import Optional, List
from datetime import datetime
import sqlite3

from app.database import get_db, init_db
from app.models import *
from app.auth import get_current_user, require_permission, can_access_application
from app.h3_utils import find_nearby_internships, get_region_analytics, lat_lng_to_h3
from app.audit_logger import log_action, get_audit_logs
from app import event_simulator

# Initialize database on startup
init_db()

app = FastAPI(title="Qadam API", description="IT Career Platform", version="1.0.0")

# ==================== AUTH ENDPOINTS ====================

@app.post("/api/auth/register", response_model=UserResponse)
def register(user: UserCreate):
    """Register new user"""
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("SELECT id FROM users WHERE username = ? OR email = ?", 
                  (user.username, user.email))
    if cursor.fetchone():
        db.close()
        raise HTTPException(status_code=400, detail="Username or email already exists")
    
    from app.auth import hash_password
    password_hash = hash_password(user.password)
    
    cursor.execute("""
    INSERT INTO users (username, email, password_hash, full_name, role)
    VALUES (?, ?, ?, ?, ?)
    """, (user.username, user.email, password_hash, user.full_name, user.role))
    
    user_id = cursor.lastrowid
    db.commit()
    
    log_action(user_id, 'user.registered', username=user.username)
    
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    new_user = cursor.fetchone()
    db.close()
    
    return dict(new_user)

@app.post("/api/auth/login")
def login(credentials: UserLogin):
    """Login to system"""
    from fastapi.security import HTTPBasicCredentials
    basic = HTTPBasicCredentials(
        username=credentials.username,
        password=credentials.password
    )
    
    from app.auth import get_current_user
    user = get_current_user(basic)
    
    return {
        "message": "Login successful",
        "user": {
            "id": user["id"],
            "username": user["username"],
            "role": user["role"],
            "full_name": user["full_name"]
        }
    }

@app.get("/api/auth/me", response_model=UserResponse)
def get_me(user: dict = Depends(get_current_user)):
    """Get current user information"""
    return user

# ==================== INTERNSHIP ENDPOINTS ====================

@app.get("/api/internships", response_model=List[InternshipResponse])
def get_internships(
    location: Optional[str] = None,
    min_salary: Optional[int] = None,
    user: dict = Depends(get_current_user)
):
    """Get list of internships"""
    db = get_db()
    cursor = db.cursor()
    
    query = "SELECT i.*, u.username as employer_name FROM internships i JOIN users u ON i.employer_id = u.id WHERE i.status = 'active'"
    params = []
    
    if location:
        query += " AND i.location LIKE ?"
        params.append(f"%{location}%")
    
    if min_salary:
        query += " AND i.salary_min >= ?"
        params.append(min_salary)
    
    query += " ORDER BY i.created_at DESC"
    
    cursor.execute(query, params)
    internships = cursor.fetchall()
    db.close()
    
    log_action(user['id'], 'internships.viewed')
    
    return [dict(i) for i in internships]

@app.post("/api/internships", response_model=InternshipResponse)
def create_internship(
    internship: InternshipCreate,
    user: dict = Depends(get_current_user)
):
    """Create new internship (employers and admins only)"""
    if not (user['role'] in ['employer', 'admin']):
        raise HTTPException(status_code=403, detail="Only employers can create internships")
    
    db = get_db()
    cursor = db.cursor()
    
    h3_index = None
    if internship.location_lat and internship.location_lng:
        h3_index = lat_lng_to_h3(internship.location_lat, internship.location_lng)
    else:
        h3_index = "88283082b9fffff"  # Default H3 index for Almaty
    
    cursor.execute("""
    INSERT INTO internships 
    (title, company, description, location, location_lat, location_lng, 
     h3_index, salary_min, salary_max, employer_id, deadline)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        internship.title,
        internship.company,
        internship.description,
        internship.location,
        internship.location_lat,
        internship.location_lng,
        h3_index,
        internship.salary_min,
        internship.salary_max,
        user['id'],
        internship.deadline
    ))
    
    internship_id = cursor.lastrowid
    db.commit()
    
    log_action(user['id'], 'internship.created', 
              entity_type='internship', entity_id=internship_id,
              new_value=internship.title)
    
    cursor.execute("SELECT * FROM internships WHERE id = ?", (internship_id,))
    new_internship = cursor.fetchone()
    db.close()
    
    return dict(new_internship)

@app.get("/api/internships/{internship_id}", response_model=InternshipResponse)
def get_internship(internship_id: int, user: dict = Depends(get_current_user)):
    """Get internship details"""
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("SELECT * FROM internships WHERE id = ?", (internship_id,))
    internship = cursor.fetchone()
    db.close()
    
    if not internship:
        raise HTTPException(status_code=404, detail="Internship not found")
    
    log_action(user['id'], 'internship.viewed', 
              entity_type='internship', entity_id=internship_id)
    
    return dict(internship)

@app.put("/api/internships/{internship_id}")
def update_internship(
    internship_id: int,
    internship_update: InternshipCreate,
    user: dict = Depends(get_current_user)
):
    """Update internship (creator or admin only)"""
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("SELECT * FROM internships WHERE id = ?", (internship_id,))
    existing = cursor.fetchone()
    
    if not existing:
        db.close()
        raise HTTPException(status_code=404, detail="Internship not found")
    
    if user['role'] != 'admin' and existing['employer_id'] != user['id']:
        db.close()
        raise HTTPException(status_code=403, detail="You can only edit your own internships")
    
    old_values = dict(existing)
    
    cursor.execute("""
    UPDATE internships 
    SET title=?, company=?, description=?, location=?, 
        salary_min=?, salary_max=?, deadline=?
    WHERE id=?
    """, (
        internship_update.title,
        internship_update.company,
        internship_update.description,
        internship_update.location,
        internship_update.salary_min,
        internship_update.salary_max,
        internship_update.deadline,
        internship_id
    ))
    
    db.commit()
    
    log_action(user['id'], 'internship.updated',
              entity_type='internship', entity_id=internship_id,
              old_value=old_values, new_value=internship_update.dict())
    
    db.close()
    return {"message": "Internship updated"}

@app.delete("/api/internships/{internship_id}")
def delete_internship(internship_id: int, user: dict = Depends(get_current_user)):
    """Delete internship (creator or admin only)"""
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("SELECT * FROM internships WHERE id = ?", (internship_id,))
    internship = cursor.fetchone()
    
    if not internship:
        db.close()
        raise HTTPException(status_code=404, detail="Internship not found")
    
    if user['role'] != 'admin' and internship['employer_id'] != user['id']:
        db.close()
        raise HTTPException(status_code=403, detail="You can only delete your own internships")
    
    cursor.execute("UPDATE internships SET status = 'deleted' WHERE id = ?", (internship_id,))
    db.commit()
    
    log_action(user['id'], 'internship.deleted',
              entity_type='internship', entity_id=internship_id,
              new_value="deleted")
    
    db.close()
    return {"message": "Internship deleted"}

# ==================== APPLICATION ENDPOINTS ====================

@app.post("/api/applications")
def create_application(
    application: ApplicationCreate,
    user: dict = Depends(get_current_user)
):
    """Apply to internship (students only)"""
    if user['role'] != 'student':
        raise HTTPException(status_code=403, detail="Only students can apply")
    
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("""
    SELECT id FROM applications 
    WHERE user_id = ? AND internship_id = ?
    """, (user['id'], application.internship_id))
    
    if cursor.fetchone():
        db.close()
        raise HTTPException(status_code=400, detail="You already applied to this internship")
    
    cursor.execute("""
    INSERT INTO applications (user_id, internship_id, cover_letter)
    VALUES (?, ?, ?)
    """, (user['id'], application.internship_id, application.cover_letter))
    
    application_id = cursor.lastrowid
    db.commit()
    
    log_action(user['id'], 'application.created',
              entity_type='application', entity_id=application_id,
              new_value=f"Internship ID: {application.internship_id}")
    
    db.close()
    return {"message": "Application submitted", "application_id": application_id}

@app.get("/api/applications/me")
def get_my_applications(user: dict = Depends(get_current_user)):
    """Get user's own applications"""
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("""
    SELECT a.*, i.title, i.company 
    FROM applications a
    JOIN internships i ON a.internship_id = i.id
    WHERE a.user_id = ?
    ORDER BY a.applied_at DESC
    """, (user['id'],))
    
    applications = cursor.fetchall()
    db.close()
    
    return [dict(app) for app in applications]

@app.get("/api/internships/{internship_id}/applications")
def get_internship_applications(
    internship_id: int,
    user: dict = Depends(get_current_user)
):
    """Get applications for an internship (employer only)"""
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("SELECT employer_id FROM internships WHERE id = ?", (internship_id,))
    internship = cursor.fetchone()
    
    if not internship:
        db.close()
        raise HTTPException(status_code=404, detail="Internship not found")
    
    if user['role'] != 'admin' and internship['employer_id'] != user['id']:
        db.close()
        raise HTTPException(status_code=403, detail="You can only view applications to your own internships")
    
    cursor.execute("""
    SELECT a.*, u.username, u.full_name, u.email
    FROM applications a
    JOIN users u ON a.user_id = u.id
    WHERE a.internship_id = ?
    ORDER BY a.applied_at DESC
    """, (internship_id,))
    
    applications = cursor.fetchall()
    db.close()
    
    return [dict(app) for app in applications]

# ==================== H3 ENDPOINTS ====================

@app.post("/api/h3/nearby")
def find_nearby(
    query: H3Query,
    user: dict = Depends(get_current_user)
):
    """Find internships near specified coordinates using H3"""
    internships = find_nearby_internships(
        lat=query.lat,
        lng=query.lng,
        radius_km=query.radius_km
    )
    
    log_action(user['id'], 'h3.nearby_query',
              details=f"lat: {query.lat}, lng: {query.lng}, radius: {query.radius_km}")
    
    return {
        "center": {"lat": query.lat, "lng": query.lng},
        "radius_km": query.radius_km,
        "count": len(internships),
        "internships": internships
    }

@app.get("/api/h3/regions")
def get_regions(
    resolution: int = 6,
    user: dict = Depends(get_current_user)
):
    """Get regional analytics aggregated by H3"""
    analytics = get_region_analytics(resolution)
    
    log_action(user['id'], 'h3.regions_query', details=f"resolution: {resolution}")
    
    return analytics

@app.get("/api/h3/region/{h3_index}")
def get_region_details(
    h3_index: str,
    user: dict = Depends(get_current_user)
):
    """Get details for specific H3 region"""
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("""
    SELECT * FROM region_analytics WHERE h3_index = ?
    """, (h3_index,))
    
    region = cursor.fetchone()
    db.close()
    
    if not region:
        raise HTTPException(status_code=404, detail="Region not found")
    
    return dict(region)

# ==================== ADMIN ENDPOINTS ====================

@app.get("/api/admin/audit-logs")
def get_audit(
    limit: int = 100,
    user_id: Optional[int] = None,
    user: dict = Depends(get_current_user)
):
    """Get audit logs (admin only)"""
    if user['role'] != 'admin':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    logs = get_audit_logs(limit, user_id)
    return logs

@app.get("/api/admin/users")
def get_users(user: dict = Depends(get_current_user)):
    """Get list of users (admin only)"""
    if user['role'] != 'admin':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("SELECT id, username, email, full_name, role, created_at FROM users")
    users = cursor.fetchall()
    db.close()
    
    return [dict(u) for u in users]

@app.delete("/api/admin/users/{user_id}")
def delete_user(
    user_id: int,
    current_user: dict = Depends(get_current_user)
):
    """Delete user (admin only)"""
    if current_user['role'] != 'admin':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    if user_id == current_user['id']:
        raise HTTPException(status_code=400, detail="Cannot delete yourself")
    
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("SELECT username FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()
    
    cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
    db.commit()
    db.close()
    
    log_action(current_user['id'], 'admin.user_deleted',
              entity_type='user', entity_id=user_id,
              new_value=f"Deleted user: {user['username']}")
    
    return {"message": "User deleted"}

# ==================== EVENT SIMULATION ENDPOINTS ====================

@app.get("/api/events/status")
def get_event_status(user: dict = Depends(get_current_user)):
    """Get event simulation status"""
    if user['role'] not in ['admin', 'employer']:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return event_simulator.get_simulation_status()

@app.post("/api/events/trigger")
def trigger_event(user: dict = Depends(get_current_user)):
    """Manually trigger an event (for demo)"""
    if user['role'] != 'admin':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    from app.event_simulator import generate_mock_internship
    from app.h3_utils import update_region_analytics
    
    mock = generate_mock_internship()
    h3_index = lat_lng_to_h3(mock["location_lat"], mock["location_lng"], 8)
    mock["h3_index"] = h3_index
    
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute("""
    INSERT INTO internships 
    (title, company, description, location, location_lat, location_lng, 
     h3_index, salary_min, salary_max, employer_id, deadline, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        mock["title"], mock["company"], mock["description"],
        mock["location"], mock["location_lat"], mock["location_lng"],
        mock["h3_index"], mock["salary_min"], mock["salary_max"],
        mock["employer_id"], mock["deadline"], "active"
    ))
    
    internship_id = cursor.lastrowid
    db.commit()
    db.close()
    
    update_region_analytics()
    
    log_action(user['id'], 'event.manually_triggered',
              entity_type='internship', entity_id=internship_id)
    
    return {"message": "Event triggered", "internship": mock}

# ==================== DEMO HELPER ====================

@app.get("/api/demo/rbac-test")
def test_rbac(user: dict = Depends(get_current_user)):
    """
    Test endpoint for RBAC demonstration
    Returns different data based on user role
    """
    if user['role'] == 'student':
        return {
            "role": "student",
            "message": "You can view internships and apply",
            "permissions": ["view", "apply"]
        }
    elif user['role'] == 'employer':
        return {
            "role": "employer",
            "message": "You can create internships and view applications",
            "permissions": ["create", "view_applications", "edit_own"]
        }
    elif user['role'] == 'mentor':
        return {
            "role": "mentor",
            "message": "You can view students and provide consultations",
            "permissions": ["view_students", "consult"]
        }
    elif user['role'] == 'admin':
        return {
            "role": "admin",
            "message": "You have full system access",
            "permissions": ["all"]
        }