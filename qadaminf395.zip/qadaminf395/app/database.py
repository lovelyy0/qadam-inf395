import sqlite3

DATABASE_PATH = "qadam.db"

def get_db():
    """Get database connection"""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize database tables (call once)"""
    conn = get_db()
    cursor = conn.cursor()
    
    # Users table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT CHECK(role IN ('student', 'employer', 'mentor', 'admin')) NOT NULL,
        location_lat REAL,
        location_lng REAL,
        h3_index TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    # Internships table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS internships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        company TEXT NOT NULL,
        description TEXT,
        location TEXT NOT NULL,
        location_lat REAL,
        location_lng REAL,
        h3_index TEXT NOT NULL,
        salary_min INTEGER,
        salary_max INTEGER,
        employer_id INTEGER NOT NULL,
        deadline DATE,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (employer_id) REFERENCES users(id)
    )
    """)
    
    # Applications table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        internship_id INTEGER NOT NULL,
        status TEXT CHECK(status IN ('pending', 'reviewed', 'interview', 'rejected', 'accepted')) DEFAULT 'pending',
        cover_letter TEXT,
        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (internship_id) REFERENCES internships(id)
    )
    """)
    
    # Audit log table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        action TEXT NOT NULL,
        entity_type TEXT,
        entity_id INTEGER,
        old_value TEXT,
        new_value TEXT,
        ip_address TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )
    """)
    
    # Region analytics table (H3 aggregated)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS region_analytics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        h3_index TEXT UNIQUE NOT NULL,
        total_internships INTEGER DEFAULT 0,
        avg_salary_min INTEGER,
        avg_salary_max INTEGER,
        companies_count INTEGER DEFAULT 0,
        applications_count INTEGER DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    conn.commit()
    conn.close()
    print("Database initialized successfully")