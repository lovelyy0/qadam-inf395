import h3
import sqlite3
from app.database import get_db

def lat_lng_to_h3(lat: float, lng: float, resolution: int = 8) -> str:
    """Convert coordinates to H3 index (for h3 version 4.x)"""
    try:
        # For h3 version 4.x
        return h3.latlng_to_cell(lat, lng, resolution)
    except AttributeError:
        try:
            # For older h3 versions
            return h3.geo_to_h3(lat, lng, resolution)
        except AttributeError:
            # Return a default H3 index if both fail
            return "88283082b9fffff"

def get_nearby_h3_indices(center_h3: str, radius_cells: int = 2) -> list:
    """Get neighboring H3 indices (for h3 version 4.x)"""
    try:
        # For h3 version 4.x
        return list(h3.grid_disk(center_h3, radius_cells))
    except AttributeError:
        try:
            # For older h3 versions
            return list(h3.k_ring(center_h3, radius_cells))
        except AttributeError:
            # Return just the center if both fail
            return [center_h3]

def find_nearby_internships(lat: float, lng: float, radius_km: int = 10):
    """
    Find internships near specified coordinates using H3 indexing
    """
    # Convert radius to H3 cells (resolution 8: each cell ~0.7km²)
    cells_radius = max(1, radius_km // 2)
    
    # Get H3 index of center point
    try:
        center_h3 = lat_lng_to_h3(lat, lng, 8)
        
        # Get neighboring indices
        neighbor_indices = get_nearby_h3_indices(center_h3, cells_radius)
    except:
        # If H3 fails, return empty list
        return []
    
    # Prepare query
    placeholders = ','.join(['?'] * len(neighbor_indices))
    
    db = get_db()
    cursor = db.cursor()
    
    query = f"""
    SELECT i.*, u.username as employer_name 
    FROM internships i
    JOIN users u ON i.employer_id = u.id
    WHERE i.h3_index IN ({placeholders})
    AND i.status = 'active'
    ORDER BY i.created_at DESC
    """
    
    cursor.execute(query, neighbor_indices)
    results = cursor.fetchall()
    db.close()
    
    return [dict(row) for row in results]

def get_region_analytics(resolution: int = 6):
    """
    Get regional analytics aggregated by H3 at specified resolution
    """
    db = get_db()
    cursor = db.cursor()
    
    # Aggregate data by H3 region (using substring for lower resolution)
    cursor.execute("""
    SELECT 
        substr(h3_index, 1, ?) as region,
        COUNT(*) as total_internships,
        AVG(salary_min) as avg_salary_min,
        AVG(salary_max) as avg_salary_max,
        COUNT(DISTINCT employer_id) as companies_count
    FROM internships
    WHERE status = 'active'
    GROUP BY region
    """, (resolution,))
    
    results = cursor.fetchall()
    db.close()
    
    return [dict(row) for row in results]

def update_region_analytics():
    """Update region analytics table with latest data"""
    db = get_db()
    cursor = db.cursor()
    
    # Clear old data
    cursor.execute("DELETE FROM region_analytics")
    
    # Insert new aggregated data
    cursor.execute("""
    INSERT INTO region_analytics (h3_index, total_internships, avg_salary_min, avg_salary_max, companies_count)
    SELECT 
        substr(h3_index, 1, 4) as h3_region,
        COUNT(*) as total_internships,
        AVG(salary_min) as avg_salary_min,
        AVG(salary_max) as avg_salary_max,
        COUNT(DISTINCT employer_id) as companies_count
    FROM internships
    WHERE status = 'active'
    GROUP BY h3_region
    """)
    
    db.commit()
    db.close()
    return {"message": "Analytics updated"}