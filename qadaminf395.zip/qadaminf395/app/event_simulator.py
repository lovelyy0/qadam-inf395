import threading
import time
import random
import sqlite3
from datetime import datetime, timedelta
from app.database import get_db
from app.audit_logger import log_action
from app.h3_utils import update_region_analytics
from app.h3_utils import lat_lng_to_h3  # Добавьте этот импорт в начало файла


simulation_running = False

def generate_mock_internship():
    """Generate random internship data for simulation"""
    companies = ["TechHub", "DataScience KZ", "Kaspi.kz", "Halyk Bank", "Chocofamily", "Yandex", "Google"]
    titles = ["Frontend Developer", "Backend Developer", "Fullstack Developer", 
              "QA Engineer", "DevOps Engineer", "Data Scientist", "Mobile Developer"]
    locations = ["Almaty", "Astana", "Karaganda", "Shymkent", "Remote"]
    
    coords = {
        "Almaty": (43.2220, 76.8512),
        "Astana": (51.1694, 71.4491),
        "Karaganda": (49.8029, 73.0874),
        "Shymkent": (42.3149, 69.5958),
        "Remote": (0, 0)
    }
    
    location = random.choice(locations)
    lat, lng = coords[location]
    
    return {
        "title": random.choice(titles),
        "company": random.choice(companies),
        "description": f"We are looking for a talented specialist to work on interesting projects",
        "location": location,
        "location_lat": lat,
        "location_lng": lng,
        "salary_min": random.randint(120000, 200000),
        "salary_max": random.randint(200000, 350000),
        "deadline": (datetime.now() + timedelta(days=random.randint(14, 60))).strftime("%Y-%m-%d"),
        "employer_id": random.randint(1, 3),
        "status": "active"
    }

def simulate_new_internships():
    """
    Event simulation - creates new internships periodically
    Runs in background thread
    """
    global simulation_running
    simulation_running = True
    
    print("Event simulator started - generating new internships every 30-60 seconds")
    
    while simulation_running:
        try:
            time.sleep(random.randint(30, 60))
            
            mock_internship = generate_mock_internship()
            
            from app.h3_utils import lat_lng_to_h3
            h3_index = lat_lng_to_h3(
                mock_internship["location_lat"], 
                mock_internship["location_lng"], 
                8
            )
            mock_internship["h3_index"] = h3_index
            
            db = get_db()
            cursor = db.cursor()
            
            cursor.execute("""
            INSERT INTO internships 
            (title, company, description, location, location_lat, location_lng, 
             h3_index, salary_min, salary_max, employer_id, deadline, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                mock_internship["title"],
                mock_internship["company"],
                mock_internship["description"],
                mock_internship["location"],
                mock_internship["location_lat"],
                mock_internship["location_lng"],
                mock_internship["h3_index"],
                mock_internship["salary_min"],
                mock_internship["salary_max"],
                mock_internship["employer_id"],
                mock_internship["deadline"],
                mock_internship["status"]
            ))
            
            internship_id = cursor.lastrowid
            db.commit()
            db.close()
            
            update_region_analytics()
            
            log_action(
                user_id=None,
                action='event.internship_created',
                entity_type='internship',
                entity_id=internship_id,
                details=f"Simulated: {mock_internship['title']} at {mock_internship['company']}"
            )
            
            print(f"[EVENT] New internship created: {mock_internship['title']} at {mock_internship['company']}")
            
        except Exception as e:
            print(f"Error in event simulation: {e}")
    
    print("Event simulator stopped")

def stop_simulation():
    """Stop the simulation"""
    global simulation_running
    simulation_running = False

def get_simulation_status():
    """Get simulation status"""
    return {"running": simulation_running}

# Start simulation in background thread
simulation_thread = threading.Thread(target=simulate_new_internships)
simulation_thread.daemon = True
simulation_thread.start()