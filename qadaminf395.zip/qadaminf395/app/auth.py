from fastapi import HTTPException, Depends, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import sqlite3
import hashlib
from app.database import get_db
from app.audit_logger import log_action

security = HTTPBasic()

def hash_password(password: str) -> str:
    """Hash password using SHA256"""
    return hashlib.sha256(password.encode()).hexdigest()

# Role-based permissions
ROLE_PERMISSIONS = {
    'student': ['view_internships', 'apply_internship', 'view_own_applications', 'save_internships'],
    'employer': ['view_internships', 'create_internship', 'edit_own_internship', 
                 'view_applications_to_own', 'delete_own_internship'],
    'mentor': ['view_internships', 'view_students', 'consult_students'],
    'admin': ['view_internships', 'create_internship', 'edit_any_internship', 
              'delete_any_internship', 'view_all_applications', 'manage_users', 
              'view_audit_logs', 'view_analytics']
}

def get_current_user(credentials: HTTPBasicCredentials = Depends(security)):
    """Get current user from Basic Auth credentials"""
    db = get_db()
    cursor = db.cursor()
    
    password_hash = hash_password(credentials.password)
    
    cursor.execute("""
    SELECT * FROM users 
    WHERE username = ? AND password_hash = ?
    """, (credentials.username, password_hash))
    
    user = cursor.fetchone()
    db.close()
    
    if not user:
        log_action(None, 'login.failed', username=credentials.username)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password"
        )
    
    log_action(user['id'], 'login.success', username=user['username'])
    
    return dict(user)

def check_permission(user: dict, required_permission: str):
    """Check if user has required permission"""
    if user['role'] not in ROLE_PERMISSIONS:
        return False
    return required_permission in ROLE_PERMISSIONS[user['role']]

def require_permission(permission: str):
    """Decorator to check permissions"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            user = None
            for arg in args:
                if isinstance(arg, dict) and 'role' in arg:
                    user = arg
                    break
            
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Could not identify user"
                )
            
            if not check_permission(user, permission):
                log_action(user['id'], 'access.denied', 
                          details=f"Required permission: {permission}")
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Insufficient permissions. Required: {permission}"
                )
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

# ABAC Rule - Attribute Based Access Control
def can_access_application(user: dict, application: dict, internship: dict) -> bool:
    """
    ABAC rule for application access:
    - Students can only see their own applications
    - Employers can see applications to their internships
    - Admins can see everything
    - Mentors see applications of their mentees
    """
    if user['role'] == 'admin':
        return True
    
    if user['role'] == 'student':
        return application['user_id'] == user['id']
    
    if user['role'] == 'employer':
        return internship['employer_id'] == user['id']
    
    if user['role'] == 'mentor':
        # In a real system, would check mentor-student relationship
        return False
    
    return False