import sqlite3
from app.database import get_db

def log_action(user_id, action, entity_type=None, entity_id=None, 
               old_value=None, new_value=None, username=None, details=None):
    """
    Log user actions for audit trail
    """
    db = get_db()
    cursor = db.cursor()
    
    ip_address = "127.0.0.1"  # Placeholder
    
    if not username and user_id:
        cursor.execute("SELECT username FROM users WHERE id = ?", (user_id,))
        result = cursor.fetchone()
        username = result['username'] if result else None
    
    cursor.execute("""
    INSERT INTO audit_log 
    (user_id, username, action, entity_type, entity_id, old_value, new_value, ip_address)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (user_id, username, action, entity_type, entity_id, 
          str(old_value) if old_value else None, 
          str(new_value) if new_value else None, 
          ip_address))
    
    db.commit()
    db.close()

def get_audit_logs(limit=100, user_id=None):
    """Retrieve audit logs"""
    db = get_db()
    cursor = db.cursor()
    
    if user_id:
        cursor.execute("""
        SELECT * FROM audit_log 
        WHERE user_id = ? 
        ORDER BY timestamp DESC 
        LIMIT ?
        """, (user_id, limit))
    else:
        cursor.execute("""
        SELECT * FROM audit_log 
        ORDER BY timestamp DESC 
        LIMIT ?
        """, (limit,))
    
    logs = cursor.fetchall()
    db.close()
    
    return [dict(log) for log in logs]