from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime

# User models
class UserBase(BaseModel):
    username: str
    email: str
    full_name: str
    role: str

class UserCreate(UserBase):
    password: str

class UserLogin(BaseModel):
    username: str
    password: str

class UserResponse(UserBase):
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

# Internship models
class InternshipBase(BaseModel):
    title: str
    company: str
    description: str
    location: str
    location_lat: Optional[float] = None
    location_lng: Optional[float] = None
    salary_min: Optional[int] = None
    salary_max: Optional[int] = None
    deadline: Optional[date] = None

class InternshipCreate(InternshipBase):
    pass

class InternshipResponse(InternshipBase):
    id: int
    h3_index: str
    employer_id: int
    status: str
    created_at: datetime
    
    class Config:
        from_attributes = True

# Application models
class ApplicationCreate(BaseModel):
    internship_id: int
    cover_letter: Optional[str] = None

class ApplicationResponse(BaseModel):
    id: int
    user_id: int
    internship_id: int
    status: str
    applied_at: datetime
    
    class Config:
        from_attributes = True

# H3 query models
class H3Query(BaseModel):
    lat: float
    lng: float
    resolution: int = 8
    radius_km: int = 10

# Event models
class EventSimulation(BaseModel):
    event_type: str
    data: dict