# Qadam - IT Career Platform (INF 395 Project)

## Group Members & Roles
- Member 1 - Backend Developer, H3 Integration
- Member 2 - Database Designer, Security
- Member 3 - API Development, Event Simulation
- Member 4 - Documentation, Testing

## Project Overview
Qadam is an institutional information system for IT career development, connecting students with internships, courses, and mentors. The system implements role-based access control, geospatial indexing with H3, audit logging, and event-driven simulation.

## How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt